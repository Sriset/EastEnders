package Directline;

import org.openqa.selenium.By;
import org.testng.Assert;

public class Utils extends BasePage {
    public static void clickButton(By by)
    {
        driver.findElement(by).click();
    }

    public static void enterElement(By by, String text)
    {
        driver.findElement(by).sendKeys(text);

    }

    public static void assertEquals(By by, String expectedResult)
    {
        String actualResult = driver.findElement(by).getText();
        //Compare Actual result with Expected result
        Assert.assertEquals(actualResult, expectedResult);

    }

}
