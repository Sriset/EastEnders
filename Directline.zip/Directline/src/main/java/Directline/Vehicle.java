package Directline;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Vehicle extends Utils {

    By vehicleReg=By.id("vehicleReg");
    By findVehicle= By.xpath("//*[@id=\"page-container\"]/div[3]/form/button/span");

    public void verifyUserIsOnTheWebPage()
    {
       //To verify user is on the HomePage
       String expected="https://covercheck.vwfsinsuranceportal.co.uk/";
       Assert.assertEquals(driver.getCurrentUrl(),expected);
    }
    public void enterRegistrationNumber()
    {
       //Enter the Registration Number
        enterElement(vehicleReg,"OV12UYY");

    }
    public void clickFindVehicleButton()
    {
        //Click the button to find the Vehicle
        clickButton(findVehicle);

    }
    public void verifyTheResultOfTheVehicle()
    {

       WebDriverWait result = new WebDriverWait(driver,30);
       result.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"page-container\"]/div[4]/div[2]/span")));
       By actualResult= By.xpath("//*[@id=\"page-container\"]/div[4]/div[2]/span");
       String expectedResult="09 FEB 2022 : 16 : 26";
       //compare the actual result with expected result
       assertEquals(actualResult,expectedResult);
    }
}
