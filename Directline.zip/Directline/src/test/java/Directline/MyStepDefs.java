package Directline;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyStepDefs extends Utils {

    Vehicle vehicle = new Vehicle();

    @Given("^user is on the given webpage$")
    public void userIsOnTheGivenWebPage()
    {
        //User is on the Given WebPage
        vehicle.verifyUserIsOnTheWebPage();
    }
    @When("^user enter the vehicle registration number$")
    public void userEnterTheVehicleRegistrationNumber()
    {
        //When user entered the Registration Number
        vehicle.enterRegistrationNumber();
    }
    @And("^user click the find vehicle button$")
    public void userClickTheFindVehicleButton()
    {
        //And Click the Find Vehicle Button
        vehicle.clickFindVehicleButton();

    }
    @Then("^user should check the cover details$")
    public void userShouldCheckTheCoverDetails()
    {
        //User should see the Vehicle cover details
        vehicle.verifyTheResultOfTheVehicle();
    }


}


