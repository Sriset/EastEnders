package Directline;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class Hooks extends Utils {


    @Before
    public void openWebPage() {

        //Set path for Chrome driver
        System.setProperty("webdriver.chrome.driver", "src\\test\\java\\Resources\\broswerdriver\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("disable-infobars");
        options.addArguments("--disable-browser-side-navigation");
        driver = new ChromeDriver(options);

        //Navigate to given URL
        driver.get("https://covercheck.vwfsinsuranceportal.co.uk/");
        // Apply implicit wait for
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
    }

    @After

    public void closeWebPage()
    {
        //Quit the driver
        driver.quit();
    }
}
